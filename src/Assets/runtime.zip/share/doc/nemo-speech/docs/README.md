# Documentation

User and developer documentation for NeMo-Speech.cpp. The shortest path
to a transcript lives in the [root README](../README.md); everything below is
the detailed manual.

Start with:

- [Installation](install.md)
- [Command-line workflows](cli.md)
- [Configuration examples](../config/README.md)
- [Model conversion](model-conversion.md)
- [Speech-to-speech VoiceChat](s2s/README.md)
- [HTTP/realtime and optional gRPC server](server.md)
- [HTTP API reference](api.md)
- [Client integration](clients.md)
- [Native SDK integration](sdk.md)
- [Troubleshooting](troubleshooting.md)
- [Build from source](build.md)

## ASR

- [Models](asr/models.md) - ready-to-run GGUF downloads, custom checkpoint
  conversion, and quantization options.
- [Configuration](asr/configuration.md) - full `asr.*` key reference plus the
  decoding / word-boosting / VAD / endpointing / diarization / postprocessing knobs.
- [Feature matrix and customization](asr/customization.md) - which models
  support which features, and request-time vs startup customization.

## SALM (speech-LLM)

- [Overview](salm/README.md) - quick start and what it does not support.
- [Models and platforms](salm/models.md) - the model files and which builds run
  the batched path.
- [Configuration](salm/configuration.md) - `asr.salm.*` keys, settings for smaller
  GPUs, concurrency and errors.
- [Transcripts and translation](salm/transcripts.md) - language, length, silence,
  custom instructions, streamed output, and speech translation.
- [Prompts](salm/prompts.md) - the prompts the server sends and example custom
  instructions.
- [Word timestamps and speakers](salm/timestamps-and-speakers.md) - how each
  entrypoint requests them, and speaker turns alone.

## TTS

- [Models](tts/models.md) - ready-to-run MagpieTTS and NanoCodec GGUF downloads,
  tokenizer setup, and custom conversion.
- [Configuration](tts/configuration.md) - `tts.*` key reference and serving.

## NMT

- [Models and conversion](nmt/models.md) - obtain and convert Riva-Translate
  models for the llama.cpp runtime.
- [Configuration](nmt/configuration.md) - `nmt.*` key reference and serving.

## S2S

- [Overview](s2s/README.md) - build and serve the streaming VoiceChat pipeline.
- [Models and conversion](s2s/models.md) - convert complete model repositories.
- [Docker deployment](s2s/docker.md) - build and run the VoiceChat server image.
- [Configuration](s2s/configuration.md) - `s2s.*` settings and runtime tuning.
- [Client integration](s2s/clients.md) - streaming, tool responses, and concurrency.

## Developer guide

- [Overview](development/README.md) - implementation and performance internals.
- [Diagnostics](development/diagnostics.md) - build switches, runtime knobs, and
  `check_backend_coverage`.
- [ASR batching](development/asr-batching.md) - neural microbatching and
  streaming-state arenas.
- [llama.cpp and ggml patches](../patches/README.md) - the project-specific changes.
- [cuBLAS shim](development/cublas-shim.md) - the in-tree drop-in cuBLAS
  replacement.
